<?php
$koneksi = new mysqli ("localhost","root","","si_perpus");
?>

<!-- end -->